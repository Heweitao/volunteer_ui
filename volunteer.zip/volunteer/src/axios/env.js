const apienv={
    dev:{
        api:"http://127.0.0.1:8000"
    },
    pro:{
        api:"http://118.24.194.76:80"
    }
}

export default apienv;
