const organ = [{
  label: "五邑大学青年志愿者协会",
  value: "1"
}, {
  label: "五邑大学智能制造学部",
  value: "2"
}, {
  label: "五邑大学经管学院",
  value: "3"
}, {
  label: "五邑大学生物科技与大健康学院",
  value: "4"
}, {
  label: "五邑大学外国语学院",
  value: "5"
}, {
  label: "五邑大学文学院",
  value: "6"
}, {
  label: "五邑大学土木建筑学院",
  value: "7"
},{
  label: "五邑大学艺术学院",
  value: "8"
}, {
  label: "五邑大学纺织材料与工程学院",
  value: "9"
}, {
  label: "五邑大学数学学院",
  value: "10"
}, {
  label: "五邑大学轨道交通学院",
  value: "11"
}, {
  label: "五邑大学应用物理与材料学院",
  value: "12"
}, {
  label: "五邑大学政法学院",
  value: "13"
}]

export default organ