import echarts from 'echarts'
import Vue from 'vue'

Vue.prototype.echarts = echarts;

export default echarts;
